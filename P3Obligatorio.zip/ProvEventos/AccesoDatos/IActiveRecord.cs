﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Diagnostics;

namespace AccesoDatos
{
    public interface IActiveRecord
    {
        #region Métodos de Active Record

        #endregion

    }
}
